package com.fpt.minhtri.quanliphonggym.sqlDAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.fpt.minhtri.quanliphonggym.bangdatabase;
import com.fpt.minhtri.quanliphonggym.database.DatabaseManager;
import com.fpt.minhtri.quanliphonggym.model.Nhanvien;

import java.util.ArrayList;
import java.util.List;

public class NhanvienDAO implements bangdatabase {
    private SQLiteDatabase database;
    private DatabaseManager databaseManager;

    public NhanvienDAO(Context context) {
        databaseManager = new DatabaseManager(context);
    }

    public boolean themnhanvien(Nhanvien nhanvien) {
        database = databaseManager.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(NHANVIEN_MA, nhanvien.getManv());
        contentValues.put(NHANVIEN_TEN, nhanvien.getTennv());
        contentValues.put(NHANVIEN_MATKHAU, nhanvien.getMatkhaunv());
        contentValues.put(NHANVIEN_MUCLUONG, nhanvien.getManv());
        long ktthemnv = database.insert(TB_NHANVIEN, null, contentValues);
        if (ktthemnv != 0) {
            return true;
        } else {
            return false;
        }
    }

    public List<Nhanvien> getAllnhanvien() {
        database = databaseManager.getWritableDatabase();
        List<Nhanvien> list = new ArrayList<>();
        String truyvan = " SELECT * FROM " + TB_NHANVIEN;
        Cursor cursor = database.rawQuery(truyvan, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Nhanvien nhanvien = new Nhanvien();
            nhanvien.setManv(cursor.getString(cursor.getColumnIndex(NHANVIEN_MA)));
            nhanvien.setTennv(cursor.getString(cursor.getColumnIndex(NHANVIEN_TEN)));
            nhanvien.setMatkhaunv(cursor.getString(cursor.getColumnIndex(NHANVIEN_MATKHAU)));
            nhanvien.setMucluongnv(cursor.getString(cursor.getColumnIndex(NHANVIEN_MUCLUONG)));
            nhanvien.setNgaycong(cursor.getString(cursor.getColumnIndex(NHANVIEN_NGAYCONG)));
            list.add(nhanvien);
        }
        return list;
    }
}

