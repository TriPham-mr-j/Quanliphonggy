package com.fpt.minhtri.quanliphonggym;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ACTdangki extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actdangki);
    }
}
