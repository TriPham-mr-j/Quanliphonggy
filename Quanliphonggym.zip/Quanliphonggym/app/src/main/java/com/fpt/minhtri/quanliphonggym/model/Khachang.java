package com.fpt.minhtri.quanliphonggym.model;

public class Khachang{
    private String makh;
    private String tenkh;
    private String gioitinh;
    private String goidangky;
    private String ngaydangky;
    private String ngayhethan;

    public String getMakh() {
        return makh;
    }

    public void setMakh(String makh) {
        this.makh = makh;
    }

    public String getTenkh() {
        return tenkh;
    }

    public void setTenkh(String tenkh) {
        this.tenkh = tenkh;
    }

    public String getGioitinh() {
        return gioitinh;
    }

    public void setGioitinh(String gioitinh) {
        this.gioitinh = gioitinh;
    }

    public String getGoidangky() {
        return goidangky;
    }

    public void setGoidangky(String goidangky) {
        this.goidangky = goidangky;
    }

    public String getNgaydangky() {
        return ngaydangky;
    }

    public void setNgaydangky(String ngaydangky) {
        this.ngaydangky = ngaydangky;
    }

    public String getNgayhethan() {
        return ngayhethan;
    }

    public void setNgayhethan(String ngayhethan) {
        this.ngayhethan = ngayhethan;
    }
}
