package com.fpt.minhtri.quanliphonggym;

public interface bangdatabase {

    String TB_ADMIN = "admin";
    String TB_NHANVIEN = "nhanvien";
    String TB_KHACHHANG = "khachhang";
    String TB_THUCHI = "thuchi";
    String TB_COSOVATCHAT = "cosovatchat";
    //bảng admin
    String ADMIN_TEN = "tenadmin";
    String ADMIN_MATKHAU = "matkhauadmin";
    // bảng nhân viên
    String NHANVIEN_MA = "manhanvien";
    String NHANVIEN_TEN = "tennhanvien";
    String NHANVIEN_MATKHAU = "matkhaunhanvien";
    String NHANVIEN_NGAYCONG = "songaycong";
    String NHANVIEN_MUCLUONG = "mucluong";
    //bang khach hang

    String KHACHHANG_MA = "makhachhang";
    String KHACHHANG_TEN = "tenkhachhang";
    String KHACHHANG_GIOITINH = "gioitinhkhachhang";
    String KHACHHANG_GOIDANGKI = "goidangki";
    String KHACHHANG_NGAYDANGKI = "ngaydangki";
    String KHACHHANG_NGAYHETHAN = "ngayhethan";
    //bang co so vat chat
    String CSVC_MATHIETBI = "mathietbi";
    String CSVC_TENTHIETBI = "tenthietbi";
    String CSVC_SOLUONG = "soluong";
    String CSVC_GIAMUA = "giamua";
    String CSVC_CHIPHIBAODUONG = "chiphibaoduong";
    String CSVC_TRANGTHAITHIETBI = "trangthaithietbi";

    // bang thu chi
    String THUCHI_CHIPHIBAODUONG = "chiphibaoduong";
    String THUCHI_MUATHIETBIMOI = "muathietbimoi";
    String THUCHI_LUONGNHANVIEN = "luongnhanvien";
    String THUCHI_KHACHHANGGIAHAN = "khachhanggiahan";
    String THUCHI_THEMMOIKHACHHANG = "khachhangmoi";

    String SQLAdmin = " CREATE TABLE " + TB_ADMIN + " ( " +
            ADMIN_TEN + " TEXT PRIMARY KEY , " +
            ADMIN_MATKHAU + " INTEGER ) ";

    String SQLNhanvien = " CREATE TABLE " + TB_NHANVIEN + " ( " +
            NHANVIEN_MA + " INTEGER PRIMARY KEY , " +
            NHANVIEN_TEN + " TEXT , " +
            NHANVIEN_MATKHAU + " TEXT , " +
            NHANVIEN_NGAYCONG + " INTEGER , " +
            NHANVIEN_MUCLUONG + " INTEGER  ) ";

    String SQLKhachhang = " CREATE TABLE " + TB_KHACHHANG + " ( " +
            KHACHHANG_MA + " INTEGER PRIMARY KEY , " +
            KHACHHANG_TEN + " TEXT , " +
            KHACHHANG_GIOITINH + " TEXT , " +
            KHACHHANG_GOIDANGKI + " TEXT ,  " +
            KHACHHANG_NGAYDANGKI + " TEXT ,  " +
            KHACHHANG_NGAYHETHAN + " TEXT ) ";

    String SQLThuchi = " CREATE TABLE " + TB_THUCHI + " ( " +
            THUCHI_CHIPHIBAODUONG + " INTEGER PRIMARY KEY , " +
            THUCHI_MUATHIETBIMOI + " INTEGER , " +
            THUCHI_LUONGNHANVIEN + " INTEGER , " +
            THUCHI_KHACHHANGGIAHAN + " INTEGER ,  " +
            THUCHI_THEMMOIKHACHHANG + " INTEGER ) ";

    String SQLCosovatchat = " CREATE TABLE " + TB_COSOVATCHAT + " ( " +
            CSVC_MATHIETBI + " INTEGER PRIMARY KEY , " +
            CSVC_TENTHIETBI + " TEXT , " +
            CSVC_SOLUONG + " INTEGER , " +
            CSVC_GIAMUA + " INTEGER ,  " +
            CSVC_CHIPHIBAODUONG + " INTEGER ,  " +
            CSVC_TRANGTHAITHIETBI + " TEXT ) ";


}
