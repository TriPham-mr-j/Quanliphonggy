package com.fpt.minhtri.quanliphonggym.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.fpt.minhtri.quanliphonggym.bangdatabase;

public class DatabaseManager extends SQLiteOpenHelper implements bangdatabase {
    public static final String DB_GYM = "dbgym";
    public static final int DBVERSION = 1;

    public DatabaseManager(Context context) {
        super(context, DB_GYM, null, DBVERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQLAdmin);
        db.execSQL(SQLNhanvien);
        db.execSQL(SQLKhachhang);
        db.execSQL(SQLCosovatchat);
        db.execSQL(SQLThuchi);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
