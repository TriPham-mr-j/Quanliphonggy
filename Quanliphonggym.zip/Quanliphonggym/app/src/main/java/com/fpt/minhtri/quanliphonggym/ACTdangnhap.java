package com.fpt.minhtri.quanliphonggym;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class ACTdangnhap extends AppCompatActivity implements View.OnClickListener{
    private EditText edtendangnhap;
    private EditText edmatkhaudangnhap;
    private CheckBox cbluumatkhau;
    private Button btdangnhap;
    private Button bthuydangnhap;
    private Button btdangki;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actdangnhap);

        edtendangnhap = (EditText) findViewById(R.id.edtendangnhap);
        edmatkhaudangnhap = (EditText) findViewById(R.id.edmatkhaudangnhap);
        cbluumatkhau = (CheckBox) findViewById(R.id.cbluumatkhau);
        btdangnhap = (Button) findViewById(R.id.btdangnhap);
        bthuydangnhap = (Button) findViewById(R.id.bthuydangnhap);
        btdangki = (Button) findViewById(R.id.btdangki);

        btdangki.setOnClickListener(this);
        btdangnhap.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btdangki:
                startActivity(new Intent(ACTdangnhap.this, ACTdangki.class));
                break;
            case R.id.btdangnhap:
                startActivity(new Intent(ACTdangnhap.this, ACTgiaodienchinh.class));
                break;

        }
    }
}
