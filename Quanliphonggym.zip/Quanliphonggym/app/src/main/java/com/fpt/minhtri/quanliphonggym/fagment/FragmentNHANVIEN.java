package com.fpt.minhtri.quanliphonggym.fagment;

import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.fpt.minhtri.quanliphonggym.R;
import com.fpt.minhtri.quanliphonggym.adapter.AdapterNhanvien;
import com.fpt.minhtri.quanliphonggym.database.DatabaseManager;
import com.fpt.minhtri.quanliphonggym.model.Nhanvien;
import com.fpt.minhtri.quanliphonggym.sqlDAO.NhanvienDAO;

import java.util.List;

public class FragmentNHANVIEN extends Fragment {
    NhanvienDAO nhanvienDAO;
    private FloatingActionButton btfthemnv;
    List<Nhanvien> nhanvienList;
    AdapterNhanvien adapterNhanvien;
    private RecyclerView rcnhanvien;
    private LinearLayoutManager linearLayoutManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragmentnhanvien, container, false);
        btfthemnv = (FloatingActionButton) view.findViewById(R.id.btfthemnv);
        rcnhanvien = (RecyclerView) view.findViewById(R.id.rcnhanvien);
        nhanvienDAO = new NhanvienDAO(getActivity());
        nhanvienList = nhanvienDAO.getAllnhanvien();
        adapterNhanvien = new AdapterNhanvien(nhanvienList, getActivity(), nhanvienDAO);
        rcnhanvien.setAdapter(adapterNhanvien);
        linearLayoutManager = new LinearLayoutManager(getActivity());
        rcnhanvien.setLayoutManager(linearLayoutManager);
        adapterNhanvien.notifyDataSetChanged();


        btfthemnv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialog dialog = new Dialog(getActivity());
                dialog.setContentView(R.layout.dialog_themnhanvien);
                final EditText edmanv = (EditText) dialog.findViewById(R.id.edmanv);
                final EditText edtennv = (EditText) dialog.findViewById(R.id.edtennv);
                final EditText edmknv1 = (EditText) dialog.findViewById(R.id.edmknv1);
                final EditText edmknv2 = (EditText) dialog.findViewById(R.id.edmknv2);
                final EditText edmucluong = (EditText) dialog.findViewById(R.id.edmucluong);
                Button btthemnv = (Button) dialog.findViewById(R.id.btthemnv);
                Button bthuynv = (Button) dialog.findViewById(R.id.bthuynv);

                btthemnv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String ma = edmanv.getText().toString().trim();
                        String ten = edtennv.getText().toString().trim();
                        String matkhau1 = edmknv1.getText().toString().trim();
                        String matkhau2 = edmknv2.getText().toString().trim();
                        String mucluong = edmucluong.getText().toString().trim();

                        if (ma.equals("")) {
                            edmanv.setError("không được để trống!!!");
                        } else if (ten.equals("")) {
                            edtennv.setError("không được để trống!!!");
                        } else if (matkhau1.equals("")) {
                            edmknv1.setError("không được để trống!!!");
                        } else if (matkhau2.equals("")) {
                            edmknv2.setError("không được để trống!!!");
//                        } else if (matkhau2 != matkhau1) {
//                            edmknv2.setError("mật khẩu nhập lại với trùng với mật khẩu");
                        } else if (mucluong.equals("")) {
                            edmucluong.setError("không được để trống !!!");
                        } else {
                            Nhanvien nhanvien = new Nhanvien();
                            nhanvien.setManv(ma);
                            nhanvien.setTennv(ten);
                            nhanvien.setMatkhaunv(matkhau1);
                            nhanvien.setMucluongnv(mucluong);
                            nhanvienDAO.themnhanvien(nhanvien);
                            Toast.makeText(getActivity(), "thêm thành công", Toast.LENGTH_LONG).show();
                        }
                    }
                });
                dialog.show();
            }
        });
        return view;
    }
}
