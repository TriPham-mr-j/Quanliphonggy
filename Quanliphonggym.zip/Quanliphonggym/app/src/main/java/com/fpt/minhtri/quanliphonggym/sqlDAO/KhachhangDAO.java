package com.fpt.minhtri.quanliphonggym.sqlDAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.fpt.minhtri.quanliphonggym.bangdatabase;
import com.fpt.minhtri.quanliphonggym.database.DatabaseManager;
import com.fpt.minhtri.quanliphonggym.model.Khachang;

public class KhachhangDAO implements bangdatabase {
    private SQLiteDatabase database;
    private DatabaseManager databaseManager;

    public KhachhangDAO (Context context) {
        databaseManager = new DatabaseManager(context);
    }
    public boolean themkhachang(Khachang khachang) {
        database = databaseManager.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(KHACHHANG_MA, khachang.getMakh());
        contentValues.put(KHACHHANG_TEN, khachang.getTenkh());
        contentValues.put(KHACHHANG_GIOITINH, khachang.getGioitinh());
        contentValues.put(KHACHHANG_GOIDANGKI, khachang.getGoidangky());
        contentValues.put(KHACHHANG_NGAYDANGKI, khachang.getNgaydangky());
        contentValues.put(KHACHHANG_NGAYHETHAN, khachang.getNgayhethan());

        long ktthemkh =  database.insert(TB_KHACHHANG,null,contentValues);
        if (ktthemkh !=0 ){
            return true;
        }else{
            return false;
        }
    }
}
