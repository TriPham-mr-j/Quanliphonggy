package com.fpt.minhtri.quanliphonggym;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;

import com.fpt.minhtri.quanliphonggym.fagment.FragmentCOSOVATCHAT;
import com.fpt.minhtri.quanliphonggym.fagment.FragmentKHACHHANG;
import com.fpt.minhtri.quanliphonggym.fagment.FragmentNHANVIEN;
import com.fpt.minhtri.quanliphonggym.fagment.FragmentTHUCHI;

public class ACTgiaodienchinh extends AppCompatActivity {

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.nvikhachhang:
                    // hien thi
                    getSupportFragmentManager().beginTransaction().replace(R.id.content1, new FragmentKHACHHANG()).commit();
                    return true;
                case R.id.nvicosovatchat:
                    getSupportFragmentManager().beginTransaction().replace(R.id.content1, new FragmentCOSOVATCHAT()).commit();
                    return true;
                case R.id.nvinhanvien:
                    getSupportFragmentManager().beginTransaction().replace(R.id.content1, new FragmentNHANVIEN()).commit();
                    return true;
                case R.id.nvithuchi:
                    getSupportFragmentManager().beginTransaction().replace(R.id.content1, new FragmentTHUCHI()).commit();
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actgiaodienchinh);
//hien thi mac dinh dau tien
        getSupportFragmentManager().beginTransaction().replace(R.id.content1, new FragmentKHACHHANG()).commit();

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }

}
