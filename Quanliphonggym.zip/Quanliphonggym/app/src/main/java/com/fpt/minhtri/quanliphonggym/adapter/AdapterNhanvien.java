package com.fpt.minhtri.quanliphonggym.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.fpt.minhtri.quanliphonggym.R;
import com.fpt.minhtri.quanliphonggym.fagment.FragmentNHANVIEN;
import com.fpt.minhtri.quanliphonggym.model.Nhanvien;
import com.fpt.minhtri.quanliphonggym.sqlDAO.NhanvienDAO;

import java.util.List;

public class AdapterNhanvien extends RecyclerView.Adapter<AdapterNhanvien.ViewHoler> {
    List<Nhanvien> nhanvienList;
    private Context context;
    private NhanvienDAO nhanvienDAO;

    public AdapterNhanvien(List<Nhanvien> nhanvienList, Context context, NhanvienDAO nhanvienDAO) {
        this.nhanvienList = nhanvienList;
        this.context = context;
        this.nhanvienDAO = nhanvienDAO;
    }

    @NonNull
    @Override
    public ViewHoler onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_nhanvien, parent, false);
        return new ViewHoler(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHoler holder, int position) {
        Nhanvien nhanvien = nhanvienList.get(position);
        holder.tvmanhanvien.setText(nhanvien.getManv());
        holder.tvtennhanvien.setText(nhanvien.getTennv());
        holder.tvmucluong.setText(nhanvien.getTennv());
        holder.tvngaycong.setText(nhanvien.getNgaycong());
    }

    @Override
    public int getItemCount() {
        return nhanvienList.size();
    }

    public class ViewHoler extends RecyclerView.ViewHolder {
        private TextView tvmanhanvien;
        private TextView tvtennhanvien;
        private TextView tvmucluong;
        private TextView tvngaycong;
        private ImageView imgdiemdanh;

        public ViewHoler(View itemView) {
            super(itemView);

            tvmanhanvien = (TextView) itemView.findViewById(R.id.tvmanv);
            tvtennhanvien = (TextView) itemView.findViewById(R.id.tvtennhanvien);
            tvmucluong = (TextView) itemView.findViewById(R.id.tvmucluong);
            tvngaycong = (TextView) itemView.findViewById(R.id.tvngaycong);
            imgdiemdanh = (ImageView) itemView.findViewById(R.id.imgdiemdanh);

        }
    }
}
