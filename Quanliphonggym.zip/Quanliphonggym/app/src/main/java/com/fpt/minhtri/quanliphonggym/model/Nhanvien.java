package com.fpt.minhtri.quanliphonggym.model;

import android.support.v7.widget.RecyclerView;

public class Nhanvien {
        private String manv;
        private String tennv;
        private String matkhaunv;
        private String mucluongnv;
        private String ngaycong;
    public String getManv() {
        return manv;
    }

    public void setManv(String manv) {
        this.manv = manv;
    }

    public String getTennv() {
        return tennv;
    }

    public void setTennv(String tennv) {
        this.tennv = tennv;
    }

    public String getMatkhaunv() {
        return matkhaunv;
    }

    public void setMatkhaunv(String matkhaunv) {
        this.matkhaunv = matkhaunv;
    }

    public String getMucluongnv() {
        return mucluongnv;
    }

    public void setMucluongnv(String mucluongnv) {
        this.mucluongnv = mucluongnv;
    }

    public String getNgaycong() {
        return ngaycong;
    }

    public void setNgaycong(String ngaycong) {
        this.ngaycong = ngaycong;
    }

}
